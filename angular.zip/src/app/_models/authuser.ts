﻿export class AuthUser {
    name: string;
    uuid: string;
    token: string;
    token_validity: number;
    refreshToken: string;
    refreshTokenExpiresIn: number;
    role: number;
    status: string;
    storageTime:number;
    redirectToUrl:string;

}