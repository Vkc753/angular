import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comman',
  templateUrl: './comman.component.html',
  styleUrls: ['./comman.component.sass']
})
export class CommanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
