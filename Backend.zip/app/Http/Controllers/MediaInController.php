<?php

namespace App\Http\Controllers;

use App\Models\MediaIn;
use App\Models\BranchRelated;
use App\Models\MediaAssessment;
use App\Models\MediaTransfer;
use App\Models\User;
use App\Models\Stage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon; 
use DB;
use App\Models\Branch;
class MediaInController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function getStagePreAnalysis($type)
    {
        if($type =="all")
        $stage = Stage::all();
        else
        $stage = Stage::where('type',$type)->get();
        return response()->json($stage);
    }

    public function mediaInList(Request $request)
    {
      // DB::connection()->enableQueryLog();
        $branchId = implode(',',$this->_getBranchId());
        $select = 'media_in.*,transfer_media.media_id as mediaId,transfer_media.new_branch_id as new_branchid, media_assessment.job_id as jobid,media_assessment.assessment_status as assstatus,branch.branch_name as branch_name,customer_detail.customer_name as customer_name';
        $query = DB::table('media_in')->select(DB::raw($select));
        $query->leftJoin("transfer_media","media_in.id", "=", DB::raw("transfer_media.media_id and media_in.transfer_id=transfer_media.id"));
        $query->leftJoin('branch', 'branch.id', '=', 'media_in.branch_id');
        $query->leftJoin('media_assessment', 'media_assessment.media_in_id', '=', 'media_in.id');
	    $query->leftJoin('customer_detail','customer_detail.id', '=','media_in.customer_id');
        if(auth()->user()->role_id !=1)
        $query->whereRaw("(media_in.branch_id in ($branchId) or transfer_media.new_branch_id in ($branchId))");
        $term = $request->input('term');
        $startDate = $request->input('startDate');
        $endDate = $request->input('endDate');
        $dateRange = $request->input('dateRange');
        $searchfieldName = $request->input('searchfieldName');
        if($term !=null && $term !='' && $searchfieldName && $searchfieldName != 'date')
        {
            if($searchfieldName == "customer_id")
            $query->where(DB::raw("customer_detail.customer_name"),'like','%'.$term.'%');
            else if($searchfieldName == "branch_id")
            $query->where(DB::raw("branch.branch_name"),'like','%'.$term.'%');
            else if( $searchfieldName=="assessment_status")
            $query->whereRaw("(media_in.assessment_status =  '".$term."' or media_assessment.assessment_status = '".$term."')");
            else
            $query->Where($searchfieldName, 'LIKE', '%'.$term.'%'); 
        }
        else if($searchfieldName == 'date' && $dateRange != '')
        {
            if($dateRange == "1")
            {
                $query->whereRaw('DATE(created_on) = CURDATE()');
            }
            else if($dateRange == "2")
            {
                $query->whereRaw('MONTH(created_on) = MONTH(CURRENT_DATE()) AND YEAR(created_on) = YEAR(CURRENT_DATE())');
            }
            else if($dateRange == "3")
            {
                $query->whereRaw('YEAR(created_on) = YEAR(CURRENT_DATE())');
            }
            else if($dateRange == "4" && $startDate != null && $endDate != null)
            {                    
                    $startDate = date('Y-m-d', strtotime($startDate))." 00:00:00";            
                    $endDate = date('Y-m-d', strtotime($endDate. ' + 1 days'))." 00:00:00";
                    $query->whereBetween('media_in.created_on',[$startDate,$endDate]);
            }

        }        
       
        $query->orderBy($request->input('orderBy'), $request->input('order'));
        $pageSize = $request->input('pageSize');
        $data = $query->paginate($pageSize,['*'],'page_no');
        $results = $data->items();
        $i = 0;
        foreach ($results as $result) {
            if($result->new_branchid !=null)
            $result->new_branchid =$this->_getBranchName($result->new_branchid);
            $i++;
        }
        $count = $data->total();
      //  $queries = DB::getQueryLog();
       // print_r($queries);die;
        $data = [
            "draw" => $request->input('draw'),
            "recordsTotal" => $count,
            "data" => $results
            ];
            return json_encode($data);     
    }

    public function getMediaAssessmentDetails($id)
    {
        $select = 'media_assessment.*,branch.branch_name as branch_name,customer_detail.customer_name as customer_name, media_in.tampered_status as tamperedStatus';
        $query = DB::table('media_assessment')->select(DB::raw($select));
        $query->where('media_assessment.id', '=',$id);
        $query->leftJoin('branch', 'branch.id', '=', 'media_assessment.branch_id');
	    $query->leftJoin('customer_detail','customer_detail.id', '=','media_assessment.customer_id');
	    $query->leftJoin('media_in','media_in.id', '=','media_assessment.media_in_id');
        $assessment =  $query->get();
        if(count($assessment) > 0)
        return response()->json($assessment[0]);
        else
        return response()->json(null);

    }

    public function generateMediaCode($id)
    {
        $transfer = MediaTransfer::find($id);
        $currentSerices =  MediaTransfer::where('new_branch_id', $transfer->new_branch_id)->max('transfer_series');
        if($currentSerices == '')
            $currentSerices = 1;
        else
            $currentSerices = $currentSerices+1;

         $code = str_pad($currentSerices,4,"0",STR_PAD_LEFT);
         $transfer->transfer_code = "HO/".$code;
         $transfer->transfer_series  = $currentSerices;
         $transfer->save();
         return response()->json($transfer);

    }

    public function sendMediatransfer(Request $request)
    {
        // $count = 1;
        // $mediaCode = DB::table('transfer_media')->where('new_branch_id',$request->input('branch_id'))->limit(1)->orderBy('id', 'DESC')->get();
        // if(count($mediaCode) > 0)
        // {
        //     $count = explode('/',$mediaCode[0]->branch_code)[1]+1;
        // }
        $media = MediaIn::find($request->input('media_id'));
        $oldBranch = Branch::find($media->branch_id);
        $newBranch = Branch::find($request->input('branch_id'));
        $transfer = new MediaTransfer();
        $transfer->old_branch_id = $media->branch_id;
        $transfer->new_branch_id = $request->input('branch_id');
        $transfer->reason = $request->input('reason');
        $transfer->media_id = $media->id;
       // $transfer->branch_code = strtoupper(substr($newBranch->branch_name, 0, 3))."/".$count;
        $transfer->created_on  = Carbon::now()->toDateTimeString();
        $transfer->save();
        $media->transfer_id = $transfer->id;
        $media->save();
        $remarks = "Media Transfer ".$oldBranch->branch_name." to ".$newBranch->branch_name." by ".$this->_getUserName(auth()->user()->id).".";
        $this->_insertMediaHistory($media,"transfer",$remarks,'media_in',$media->assessment_status);
        return response()->json($media);
    }

    public function getMediaDetails($id)
    {
        $select = 'media_in.*,branch.branch_name as branch_name,customer_detail.customer_name as customer_name,users.name as user_name';
        $query = DB::table('media_in')->select(DB::raw($select));
        $query->where('media_in.id', '=',$id);
        $query->leftJoin('branch', 'branch.id', '=', 'media_in.branch_id');
	    $query->leftJoin('customer_detail','customer_detail.id', '=','media_in.customer_id');
        $query->leftJoin('users', 'users.id', '=', 'media_in.user_id'); 
        $midiain =  $query->get();
            if(count($midiain) > 0)
            {
                $midiain[0]->medaiassessment = null;
                $midiain[0]->transferMedia = null;
                $query = DB::table('media_assessment')->select(DB::raw("media_assessment.*,users.name as user_name"));
                $query->where('media_assessment.media_in_id', '=',$midiain[0]->id);
                $query->leftJoin('users', 'users.id', '=', 'media_assessment.user_id');                
                $assessment =  $query->get();
                if(count($assessment) > 0)
                {
                    $midiain[0]->medaiassessment = $assessment[0];
                }
                if($midiain[0]->transfer_id != null)
                {
                    $midiain[0]->transferMedia =  MediaTransfer::find($midiain[0]->transfer_id);
                }
                return response()->json($midiain[0]);
            }
            else
            {
                return response()->json(null);
            }
        
    }

    public function getMediaHistory($id,$type,$module)
    {
        $select = 'mims_remark.*,users.name as user_name';
        $query = DB::table('mims_remark')->select(DB::raw($select));
        $query->where('mims_remark.mediain_id', '=',$id);
        $query->where('mims_remark.type', '=',$type);
        $query->where('mims_remark.module', '=',$module);
        $query->leftJoin('users', 'users.id', '=', 'mims_remark.added_by');
        $query->orderBy('id','asc');
        $mimsremarks =  $query->get();
        return response()->json($mimsremarks);
    }

    public function getMediaInUserList($id)
    {
        $mediaIn = MediaIn::find($id);
        $branchId = $mediaIn->branch_id;
        $transfer_id = $mediaIn->transfer_id;
        if($branchId != null && $transfer_id !=null)
        {
            $transfer = MediaTransfer::find($transfer_id);
            $branchs = BranchRelated::whereIn('branch_id',[$branchId,$transfer->new_branch_id])->get();
        }
        else
        {
            $branchs = BranchRelated::where('branch_id',$branchId)->get();
        }        
        $userId = array();
        foreach($branchs as $branch)
        {
            $userId[] = $branch->user_id;
        }
        $userId = array_unique($userId);
        $users = User::whereIn('id',$userId)->get();
        return response()->json($users);
    }

    public function getAssessmentUserList($id)
    {
        $mediaAssessment = MediaAssessment::find($id);
        $mediaPre = MediaIn::find($mediaAssessment->media_in_id);
        if($mediaPre->transfer_id == null)
        {
            $branchs = BranchRelated::where('branch_id',$mediaAssessment->branch_id)->get();
        }        
        else 
        {
            $transfer = MediaTransfer::find($mediaPre->transfer_id);
            $branchs = BranchRelated::whereIn('branch_id',[$mediaAssessment->branch_id,$transfer->new_branch_id])->get();
        }
        $userId = array();
        foreach($branchs as $branch)
        {
            $userId[] = $branch->user_id;
        }
        $userId = array_unique($userId);
        $users = User::whereIn('id',$userId)->get();
        return response()->json($users);
    }

    public function changeMediaInAssign(Request $request)
    {
            $mediaIn = MediaIn::find($request->input('mediain_id'));
            $mediaIn->user_id = $request->input('user_id');
            $mediaIn->save();
            $remarks = "Lab Technician changed to ".$this->_getUserName($mediaIn->user_id)." by ".$this->_getUserName(auth()->user()->id).".";
            $this->_insertMediaHistory($mediaIn,"assign",$remarks,'media_in',$mediaIn->assessment_status);
            return response()->json($mediaIn);
    }

    public function changeAssessmentAssign(Request $request)
    {
            $media = MediaAssessment::find($request->input('mediain_id'));
            $media->user_id = $request->input('user_id');
            $media->save();
            $remarks = "Lab Technician changed to ".$this->_getUserName($media->user_id)." by ".$this->_getUserName(auth()->user()->id).".";
            $this->_insertMediaHistory($media,"assign",$remarks,'assessment',$media->assessment_status);
            return response()->json($media);
    }

    function _insertMediaHistory($mediaIn,$type,$remarks,$module,$status)
    {
        DB::insert('insert into mims_remark (mediain_id,added_by,type,remarks,module,added_on,media_status) values (?,?,?,?,?,?,?)', array($mediaIn->id, auth()->user()->id,
        $type,$remarks,$module,Carbon::now()->toDateTimeString(),$status));
    }

    function updateMediaAssessment(Request $request)
    {
        $stage = Stage::where('stage_name',$request->input('assessment_status'))->first();
        $id = $request->input('id');
        $assessment = MediaAssessment::find($id);
        $assessment->access_percentage = $request->input('access_percentage');
        $assessment->assessment_status = $request->input('assessment_status');
        $assessment->case_type = $request->input('case_type');
        $assessment->no_recovery_reason = $request->input('no_recovery_reason');
        $assessment->recoverable_data = $request->input('recoverable_data');
        $assessment->recovery_percentage = $request->input('recovery_percentage');
        $assessment->recovery_possibility = $request->input('recovery_possibility');
        $assessment->required_days = $request->input('required_days');
        $assessment->tampering_required = $request->input('tampering_required');
        $assessment->recoverable_data = $request->input('recoverable_data');
        $assessment->assessment_due_reason = $request->input('assessment_due_reason');
        $assessment->selected_data = $request->input('selected_data');
        $assessment->media_os = $request->input('media_os');
        $assessment->media_firmware = $request->input('media_firmware');
        $assessment->encryption_status = $request->input('encryption_status');
        $assessment->extension_required = $request->input('extension_required');
        $assessment->extension_day = $request->input('extension_day');
        $assessment->stage = $stage->id;
        $assessment->assessment_updated = Carbon::now()->toDateTimeString();
        $assessment->save();
        $this->_insertMediaHistory($assessment,"edit",$request->input('remarks'),'assessment',$assessment->assessment_status);
        return response()->json($assessment);
    }

    function updateMediaIn(Request $request)
    {
        $stage = Stage::where('stage_name',$request->input('assessment_status'))->first();
        $mediaInId = $request->input('id');
        $mediaIn = MediaIn::find($mediaInId);
        $mediaIn->media_make = $request->input('media_make');
        $mediaIn->media_model = $request->input('media_model');
        $mediaIn->media_serial = $request->input('media_serial');
        $mediaIn->media_capacity = $request->input('media_capacity');
        $mediaIn->tampered_status = $request->input('tampered_status');
        $mediaIn->media_condition = $request->input('media_condition');
        $mediaIn->assessment_status = $request->input('assessment_status');
        $mediaIn->peripherals_details = $request->input('peripherals_details');
        $mediaIn->last_updated  = Carbon::now()->toDateTimeString();
        $mediaIn->stage = $stage->id;
        $mediaIn->save();
        $this->_insertMediaHistory($mediaIn,"edit",$request->input('remarks'),'media_in',$mediaIn->assessment_status);
        return response()->json($mediaIn);

    }

    public function getAllBranch()
    {
        $branchs = Branch::all();
        return response()->json($branchs);
    }

}
