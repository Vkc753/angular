export const environment = {
  production: true,
  apiUrl:"http://172.16.110.86/mims/mims-api-live/public/api/"
};
