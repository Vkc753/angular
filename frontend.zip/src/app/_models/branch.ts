export class Branch {
    id:number;
    branch_name: string;
    country_id: string;
    state_name: string;
    address: string;
}