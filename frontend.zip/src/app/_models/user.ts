export class User {
    id?:string;
    name?: string;
    email?:string;
    emp_code?:string;
    description:string;
    complete?:boolean;
}